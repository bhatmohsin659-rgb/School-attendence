package com.schoolattendance.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.graphics.Color;

public class MainActivity extends Activity {
    int present = 0, absent = 0;
    TextView presentView, absentView, historyView;
    EditText name;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.studentName);
        presentView = findViewById(R.id.presentCount);
        absentView = findViewById(R.id.absentCount);
        historyView = findViewById(R.id.history);

        findViewById(R.id.presentButton).setOnClickListener(v -> mark(true));
        findViewById(R.id.absentButton).setOnClickListener(v -> mark(false));
    }

    void mark(boolean isPresent) {
        String student = name.getText().toString().trim();
        if (student.isEmpty()) {
            name.setError("Enter student name");
            return;
        }
        if (isPresent) present++; else absent++;
        presentView.setText("Present\n" + present);
        absentView.setText("Absent\n" + absent);

        String status = isPresent ? "Present" : "Absent";
        String old = historyView.getText().toString();
        historyView.setText(old.equals("Attendance history will appear here.")
                ? student + " — " + status
                : old + "\n" + student + " — " + status);
        Toast.makeText(this, student + " marked " + status, Toast.LENGTH_SHORT).show();
    }
}
