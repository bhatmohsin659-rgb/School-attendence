# School Attendance — APK-ready Android project

This is a clean starter Android Studio project for the School Attendance app.

Included:
- Student name
- Subjects: Mathematics, English, Computer Science, BCA / Practical
- Mark Present / Absent
- Today's counters
- Simple attendance history
- Portrait Android app configuration

## Build APK
1. Install Android Studio.
2. Open this folder as a project.
3. Let Gradle sync.
4. Select **Build > Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/`.

This version is a working starter. Data is currently kept only while the app is open; the next version can add permanent storage, student roster, dates, attendance percentage, login, and export.
